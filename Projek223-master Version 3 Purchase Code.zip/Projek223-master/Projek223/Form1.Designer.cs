﻿namespace Projek223
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlReports = new System.Windows.Forms.Panel();
            this.lblReports = new System.Windows.Forms.Label();
            this.pnlPurchases = new System.Windows.Forms.Panel();
            this.lblPurchases = new System.Windows.Forms.Label();
            this.pnlSales = new System.Windows.Forms.Panel();
            this.lblSales = new System.Windows.Forms.Label();
            this.pnlGrowth = new System.Windows.Forms.Panel();
            this.lblGrowth = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSalad = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pnlFORMS = new System.Windows.Forms.Panel();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblMinimize = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblExit = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlReports.SuspendLayout();
            this.pnlPurchases.SuspendLayout();
            this.pnlSales.SuspendLayout();
            this.pnlGrowth.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.pnlReports);
            this.panel1.Controls.Add(this.pnlPurchases);
            this.panel1.Controls.Add(this.pnlSales);
            this.panel1.Controls.Add(this.pnlGrowth);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(264, 1057);
            this.panel1.TabIndex = 0;
            // 
            // pnlReports
            // 
            this.pnlReports.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.pnlReports.Controls.Add(this.lblReports);
            this.pnlReports.Location = new System.Drawing.Point(10, 497);
            this.pnlReports.Name = "pnlReports";
            this.pnlReports.Size = new System.Drawing.Size(243, 86);
            this.pnlReports.TabIndex = 2;
            this.pnlReports.Click += new System.EventHandler(this.pnlReports_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblReports.Location = new System.Drawing.Point(63, 22);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(110, 43);
            this.lblReports.TabIndex = 0;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // pnlPurchases
            // 
            this.pnlPurchases.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.pnlPurchases.Controls.Add(this.lblPurchases);
            this.pnlPurchases.Location = new System.Drawing.Point(8, 384);
            this.pnlPurchases.Name = "pnlPurchases";
            this.pnlPurchases.Size = new System.Drawing.Size(243, 86);
            this.pnlPurchases.TabIndex = 2;
            this.pnlPurchases.Click += new System.EventHandler(this.pnlPurchases_Click);
            // 
            // lblPurchases
            // 
            this.lblPurchases.AutoSize = true;
            this.lblPurchases.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchases.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPurchases.Location = new System.Drawing.Point(53, 21);
            this.lblPurchases.Name = "lblPurchases";
            this.lblPurchases.Size = new System.Drawing.Size(136, 43);
            this.lblPurchases.TabIndex = 0;
            this.lblPurchases.Text = "Purchases";
            this.lblPurchases.Click += new System.EventHandler(this.lblPurchases_Click);
            // 
            // pnlSales
            // 
            this.pnlSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.pnlSales.Controls.Add(this.lblSales);
            this.pnlSales.Location = new System.Drawing.Point(8, 272);
            this.pnlSales.Name = "pnlSales";
            this.pnlSales.Size = new System.Drawing.Size(243, 86);
            this.pnlSales.TabIndex = 2;
            this.pnlSales.Click += new System.EventHandler(this.pnlSales_Click);
            // 
            // lblSales
            // 
            this.lblSales.AutoSize = true;
            this.lblSales.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSales.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSales.Location = new System.Drawing.Point(78, 21);
            this.lblSales.Name = "lblSales";
            this.lblSales.Size = new System.Drawing.Size(77, 43);
            this.lblSales.TabIndex = 0;
            this.lblSales.Text = "Sales";
            this.lblSales.Click += new System.EventHandler(this.lblSales_Click);
            // 
            // pnlGrowth
            // 
            this.pnlGrowth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(168)))), ((int)(((byte)(168)))));
            this.pnlGrowth.Controls.Add(this.lblGrowth);
            this.pnlGrowth.Location = new System.Drawing.Point(8, 159);
            this.pnlGrowth.Name = "pnlGrowth";
            this.pnlGrowth.Size = new System.Drawing.Size(243, 86);
            this.pnlGrowth.TabIndex = 1;
            this.pnlGrowth.Click += new System.EventHandler(this.pnlGrowth_Click);
            // 
            // lblGrowth
            // 
            this.lblGrowth.AutoSize = true;
            this.lblGrowth.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrowth.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblGrowth.Location = new System.Drawing.Point(31, 21);
            this.lblGrowth.Name = "lblGrowth";
            this.lblGrowth.Size = new System.Drawing.Size(188, 43);
            this.lblGrowth.TabIndex = 0;
            this.lblGrowth.Text = "Growth cycles";
            this.lblGrowth.Click += new System.EventHandler(this.lblGrowth_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(138)))), ((int)(((byte)(53)))));
            this.panel2.Controls.Add(this.lblSalad);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(264, 100);
            this.panel2.TabIndex = 0;
            // 
            // lblSalad
            // 
            this.lblSalad.AutoSize = true;
            this.lblSalad.Font = new System.Drawing.Font("Lucida Calligraphy", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalad.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSalad.Location = new System.Drawing.Point(3, 33);
            this.lblSalad.Name = "lblSalad";
            this.lblSalad.Size = new System.Drawing.Size(248, 37);
            this.lblSalad.TabIndex = 0;
            this.lblSalad.Text = "Salad Confetti";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pnlFORMS);
            this.splitContainer1.Panel2.Controls.Add(this.splitter2);
            this.splitContainer1.Panel2.Controls.Add(this.splitter1);
            this.splitContainer1.Panel2.Controls.Add(this.panel3);
            this.splitContainer1.Size = new System.Drawing.Size(1347, 1057);
            this.splitContainer1.SplitterDistance = 260;
            this.splitContainer1.SplitterWidth = 2;
            this.splitContainer1.TabIndex = 1;
            // 
            // pnlFORMS
            // 
            this.pnlFORMS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFORMS.Location = new System.Drawing.Point(3, 41);
            this.pnlFORMS.Name = "pnlFORMS";
            this.pnlFORMS.Size = new System.Drawing.Size(1082, 1016);
            this.pnlFORMS.TabIndex = 3;
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter2.Location = new System.Drawing.Point(3, 38);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(1082, 3);
            this.splitter2.TabIndex = 2;
            this.splitter2.TabStop = false;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 38);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 1019);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1085, 38);
            this.panel3.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.lblMinimize);
            this.panel5.Location = new System.Drawing.Point(945, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(67, 36);
            this.panel5.TabIndex = 4;
            this.panel5.Click += new System.EventHandler(this.panel5_Click);
            this.panel5.MouseEnter += new System.EventHandler(this.panel5_MouseEnter);
            this.panel5.MouseLeave += new System.EventHandler(this.panel5_MouseLeave);
            // 
            // lblMinimize
            // 
            this.lblMinimize.AutoSize = true;
            this.lblMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinimize.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblMinimize.Location = new System.Drawing.Point(20, -3);
            this.lblMinimize.Name = "lblMinimize";
            this.lblMinimize.Size = new System.Drawing.Size(30, 39);
            this.lblMinimize.TabIndex = 0;
            this.lblMinimize.Text = "-";
            this.lblMinimize.Click += new System.EventHandler(this.lblMinimize_Click);
            this.lblMinimize.MouseEnter += new System.EventHandler(this.lblMinimize_MouseEnter);
            this.lblMinimize.MouseLeave += new System.EventHandler(this.lblMinimize_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.lblExit);
            this.panel4.Location = new System.Drawing.Point(1018, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(67, 36);
            this.panel4.TabIndex = 3;
            this.panel4.Click += new System.EventHandler(this.panel4_Click);
            this.panel4.MouseEnter += new System.EventHandler(this.panel4_MouseEnter);
            this.panel4.MouseLeave += new System.EventHandler(this.panel4_MouseLeave);
            // 
            // lblExit
            // 
            this.lblExit.AutoSize = true;
            this.lblExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblExit.Location = new System.Drawing.Point(23, 9);
            this.lblExit.Name = "lblExit";
            this.lblExit.Size = new System.Drawing.Size(21, 20);
            this.lblExit.TabIndex = 0;
            this.lblExit.Text = "X";
            this.lblExit.Click += new System.EventHandler(this.lblExit_Click);
            this.lblExit.MouseEnter += new System.EventHandler(this.lblExit_MouseEnter);
            this.lblExit.MouseLeave += new System.EventHandler(this.lblExit_MouseLeave);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(60)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1347, 1057);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "frmMain";
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.pnlReports.ResumeLayout(false);
            this.pnlReports.PerformLayout();
            this.pnlPurchases.ResumeLayout(false);
            this.pnlPurchases.PerformLayout();
            this.pnlSales.ResumeLayout(false);
            this.pnlSales.PerformLayout();
            this.pnlGrowth.ResumeLayout(false);
            this.pnlGrowth.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblExit;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblMinimize;
        private System.Windows.Forms.Label lblSalad;
        private System.Windows.Forms.Panel pnlGrowth;
        private System.Windows.Forms.Panel pnlReports;
        private System.Windows.Forms.Panel pnlPurchases;
        private System.Windows.Forms.Panel pnlSales;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblPurchases;
        private System.Windows.Forms.Label lblSales;
        private System.Windows.Forms.Label lblGrowth;
        private System.Windows.Forms.Panel pnlFORMS;
    }
}

